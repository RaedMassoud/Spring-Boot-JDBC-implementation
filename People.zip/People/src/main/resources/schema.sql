CREATE TABLE person (
    id int,
    first_name varchar(20),
    last_name varchar(20),
    city varchar(40)
    );