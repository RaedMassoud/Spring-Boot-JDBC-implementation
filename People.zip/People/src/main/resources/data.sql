INSERT into person (id, first_name, last_name, city) values (1, 'Mike', 'Zaytone','Beirut');
INSERT into person (id, first_name, last_name, city) values (2, 'Jack', 'Massoud', 'Beirut');
INSERT into person (id, first_name, last_name, city) values (3, 'Joseph', 'Fares', 'Beirut');
INSERT into person (id, first_name, last_name, city) values (4, 'Marc', 'Taha', 'Achrafieh');
INSERT into person (id, first_name, last_name, city) values (5, 'Ryan', 'Tofaily', 'Hamra');
INSERT into person (id, first_name, last_name, city) values (6, 'Joy', 'Zakour', 'Beirut');
INSERT into person (id, first_name, last_name, city) values (7, 'Misho', 'Jamal', 'Achrafieh');
INSERT into person (id, first_name, last_name, city) values (8, 'Francisco', 'Halabi', 'Achrafieh');
